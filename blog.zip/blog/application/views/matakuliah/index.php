<div class="col-md-12">
<h3>Selamat Datang mahasiswa</h3>
    <table border="1" class="table">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Mata Kuliah</th>
                <th>SKS</th>
                <th>Kode</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $nomor = 1;
            foreach($matakuliah as $sks){
            ?>
            <tr>
                <td><?php echo $nomor?></td>
                <td><?php echo $sks->nama?></td>
                <td><?php echo $sks->sks?></td>
                <td><?php echo $sks->kode?></td>
            </tr>
            <?php
            $nomor++;
            }
            ?>
        </tbody>
    </table>
</div>